#include <stdio.h>

// Hello World Program in C

int main()
{
	printf("Hello World\n");
	return 0;
}
